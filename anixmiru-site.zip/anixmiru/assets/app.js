// AnixMiru — shared interactivity
document.addEventListener('DOMContentLoaded', () => {

  // Mobile menu toggle → reveals nav links stacked
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('mobile-open');
      navLinks.style.cssText = open
        ? 'display:flex; flex-direction:column; gap:14px; position:absolute; top:100%; left:0; right:0; background:#150c22; padding:20px 32px; border-bottom:1px solid rgba(255,255,255,0.08);'
        : '';
      menuToggle.textContent = open ? '✕' : '☰';
    });
  }

  // Genre / filter pill toggles (visual only)
  document.querySelectorAll('.pills, .filter-tags').forEach(group => {
    group.addEventListener('click', (e) => {
      const target = e.target.closest('.pill, .tag');
      if (!target) return;
      if (group.classList.contains('pills')) {
        group.querySelectorAll('.pill').forEach(p => p.classList.remove('active'));
      }
      target.classList.toggle('active');
    });
  });

  // Tabs (detail page)
  document.querySelectorAll('.tabs').forEach(tabGroup => {
    tabGroup.addEventListener('click', (e) => {
      const tab = e.target.closest('.tab');
      if (!tab) return;
      tabGroup.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const targetSel = tab.getAttribute('data-target');
      if (targetSel) {
        document.querySelectorAll('.tab-panel').forEach(p => p.style.display = 'none');
        const panel = document.querySelector(targetSel);
        if (panel) panel.style.display = '';
      }
    });
  });

  // Server chip toggle (watch page)
  document.querySelectorAll('.server-row').forEach(row => {
    row.addEventListener('click', (e) => {
      const chip = e.target.closest('.server-chip');
      if (!chip) return;
      row.querySelectorAll('.server-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    });
  });

  // Sidebar episode active state (watch page)
  document.querySelectorAll('.side-list').forEach(list => {
    list.addEventListener('click', (e) => {
      const ep = e.target.closest('.side-ep');
      if (!ep) return;
      list.querySelectorAll('.side-ep').forEach(x => x.classList.remove('active'));
      ep.classList.add('active');
    });
  });

  // Player play/pause toggle (visual only)
  const playerCenter = document.querySelector('.player-center');
  if (playerCenter) {
    playerCenter.addEventListener('click', () => {
      playerCenter.style.opacity = playerCenter.style.opacity === '0' ? '1' : '0';
    });
  }

  // Nav search + hero/browse search → route to search.html?q=
  document.querySelectorAll('form[data-search]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = form.querySelector('input');
      const q = input && input.value.trim();
      window.location.href = 'search.html' + (q ? ('?q=' + encodeURIComponent(q)) : '');
    });
  });

  // On search.html, echo the query into the page
  const params = new URLSearchParams(window.location.search);
  const q = params.get('q');
  const echoEl = document.querySelector('[data-query-echo]');
  if (echoEl) {
    echoEl.textContent = q ? q : '';
    const input = document.querySelector('form[data-search] input');
    if (input && q) input.value = q;
  }

  // Fake comment submit
  const commentForm = document.querySelector('.comment-form');
  if (commentForm) {
    const btn = commentForm.querySelector('button');
    const textarea = commentForm.querySelector('textarea');
    if (btn && textarea) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        if (!textarea.value.trim()) return;
        const list = document.querySelector('.comments-list');
        if (list) {
          const item = document.createElement('div');
          item.className = 'comment';
          item.innerHTML = `<div class="avatar"></div><div class="body"><div class="who">You <span>just now</span></div><p></p></div>`;
          item.querySelector('p').textContent = textarea.value.trim();
          list.prepend(item);
        }
        textarea.value = '';
      });
    }
  }
});
